# FMS Platform API — 第一階段端點清單

`openapi.yaml` 已完整定義核心 53 個 operation（含 request/response schema 與範例）。
本清單是**完整端點盤點**：標記 `契約` 的已在 OpenAPI 中定義，標記 `待補` 的為同一階段內
需實作、但 schema 沿用既有模型、可在 Sprint 中直接補進契約檔的端點。

前端團隊只需依 `openapi.yaml` 產生 client；本表用於進度追蹤與範圍確認。

---

## 通用規範速查

| 項目 | 規範 |
|---|---|
| Base path | `/api/v1` |
| 必要標頭 | `Authorization: Bearer <jwt>`、`X-Tenant-ID` |
| 選用標頭 | `X-Org-ID`、`X-Facility-ID`、`X-Request-ID`、`Idempotency-Key`、`If-Match` |
| 分頁 | `?limit=50&cursor=...` → `{ data: [], page: { next_cursor, limit, total_estimate } }` |
| 排序 | `?sort=-created_at,name` |
| 過濾 | 具名查詢參數；多值以逗號表示 OR（`?status=ASSIGNED,IN_PROGRESS`） |
| 稀疏欄位 | `?fields=id,wo_no,status` |
| 關聯展開 | `?include=tasks,comments`（白名單，避免 N+1 爆炸） |
| 錯誤 | `application/problem+json`（RFC 9457）+ 穩定 `code` |
| 樂觀鎖 | 具 `version` 的資源：`ETag` / `If-Match`，衝突回 `412` |
| 冪等 | 建立類 POST 支援 `Idempotency-Key`，24h TTL |
| 軟刪除 | `DELETE` 為軟刪除，回 `204`；被引用時回 `409` |

---

## 1. Auth & Identity

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| POST | `/auth/token` | 發放權杖（password / authorization_code / client_credentials） | — | 契約 |
| POST | `/auth/token/refresh` | 更新權杖 | — | 契約 |
| POST | `/auth/logout` | 撤銷 refresh token | 已登入 | 待補 |
| GET | `/auth/me` | 使用者 + 可用場館 + 有效權限 | 已登入 | 契約 |
| GET | `/auth/sso/{providerCode}/authorize` | 導向 IdP（回傳 302 或 authorize_url） | — | 待補 |
| GET | `/auth/sso/{providerCode}/callback` | OIDC/SAML 回跳處理 | — | 待補 |
| POST | `/auth/password/change` | 變更本地帳號密碼 | 已登入 | 待補 |
| GET | `/identity-providers` | 列出身分來源 | `identity_provider:read` | 契約 |
| POST | `/identity-providers` | 新增身分來源 | `identity_provider:write` | 契約 |
| PATCH | `/identity-providers/{id}` | 修改身分來源 | `identity_provider:write` | 待補 |
| POST | `/identity-providers/{id}/test-connection` | 測試 LDAP bind / OIDC discovery | `identity_provider:write` | 待補 |
| POST | `/identity-providers/{id}/sync` | 觸發目錄同步 | `directory:sync` | 契約 |
| GET | `/identity-providers/{id}/sync-runs` | 同步歷程與統計 | `identity_provider:read` | 待補 |
| GET | `/directory-groups` | 已同步的 AD/Entra 群組 | `identity_provider:read` | 待補 |
| GET | `/directory-role-mappings` | 群組→角色對應清單 | `role:read` | 待補 |
| POST | `/directory-role-mappings` | 建立群組→角色對應 | `role:write` | 待補 |
| DELETE | `/directory-role-mappings/{id}` | 刪除對應 | `role:write` | 待補 |
| GET/POST/PATCH/DELETE | `/scim/v2/Users`, `/scim/v2/Groups` | SCIM 2.0 供裝端點（供 Entra ID 推送） | SCIM token | 待補 |

> **混合式 AD 的設計要點**：認證與授權分離。認證可能來自 Entra ID、地端 AD（LDAPS 或 ADFS）
> 或本地帳號；授權一律落在 `user_role_assignments` 上，並以 `source` 區分是人工指派或目錄同步
> 產生。目錄同步只增刪 `source='DIRECTORY_SYNC'` 的授權，永不動人工授權——這是避免
> 「同步一次把管理員權限清掉」的關鍵約束。

## 2. Tenancy

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/tenant` | 目前租戶設定與功能開關 | `tenant:read` | 待補 |
| PATCH | `/tenant` | 更新租戶設定 | `tenant:update` | 待補 |
| GET | `/organizations` | 組織清單（支援 `subtree_of`） | `organization:read` | 契約 |
| POST | `/organizations` | 建立組織 | `organization:write` | 契約 |
| GET | `/organizations/{id}` | 組織詳情 | `organization:read` | 待補 |
| PATCH | `/organizations/{id}` | 更新組織（含移動父層，會重算 ltree 子樹） | `organization:write` | 待補 |
| DELETE | `/organizations/{id}` | 刪除組織（有下層或設施時回 409） | `organization:write` | 待補 |
| GET | `/facilities` | 設施清單（自動限縮於可存取範圍） | `facility:read` | 契約 |
| POST | `/facilities` | 建立設施 | `facility:write` | 契約 |
| GET | `/facilities/{id}` | 設施詳情 | `facility:read` | 契約 |
| PATCH | `/facilities/{id}` | 更新設施 | `facility:write` | 契約 |

## 3. Spatial & BIM

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/facilities/{facilityId}/spatial-nodes` | 空間節點（`view=flat\|tree`） | `spatial_node:read` | 契約 |
| POST | `/facilities/{facilityId}/spatial-nodes` | 建立節點 | `spatial_node:write` | 契約 |
| GET | `/spatial-nodes/{id}` | 節點詳情（含設備摘要） | `spatial_node:read` | 待補 |
| PATCH | `/spatial-nodes/{id}` | 更新節點（含 re-parent） | `spatial_node:write` | 待補 |
| DELETE | `/spatial-nodes/{id}` | 刪除節點 | `spatial_node:write` | 待補 |
| POST | `/facilities/{facilityId}/spatial-nodes:bulk-import` | 批次匯入樓層/房間（CSV/JSON） | `spatial_node:write` | 待補 |
| GET | `/spatial-node-types` | 節點型別（平台 + 租戶自訂） | `spatial_node:read` | 待補 |
| GET | `/facilities/{facilityId}/bim-models` | BIM 模型清單 | `bim_model:read` | 契約 |
| POST | `/facilities/{facilityId}/bim-models` | 註冊模型並排入解析 | `bim_model:write` | 契約 |
| GET | `/bim-models/{id}` | 模型詳情與解析報告 | `bim_model:read` | 待補 |
| GET | `/bim-models/{id}/unresolved-elements` | 未對應元件（人工補正） | `bim_model:read` | 契約 |
| POST | `/bim-models/{id}/mappings` | 手動對應元件↔節點/設備 | `bim_model:write` | 待補 |
| GET | `/facilities/{facilityId}/floor-view` | 逐層檢視資料（節點 + 設備 + 告警 + 幾何） | `spatial_node:read` | 待補 |

## 4. Assets

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/assets` | 查詢設備 | `asset:read` | 契約 |
| POST | `/assets` | 建立設備 | `asset:write` | 契約 |
| GET | `/assets/{id}` | 詳情（`include=children,relations,meters,...`） | `asset:read` | 契約 |
| PATCH | `/assets/{id}` | 更新設備 | `asset:write` | 契約 |
| DELETE | `/assets/{id}` | 報廢／刪除 | `asset:delete` | 契約 |
| GET | `/assets/{id}/dependency-graph` | 跨系統依賴圖 | `asset:read` | 契約 |
| POST | `/assets/{id}/relations` | 建立依賴關係 | `asset:write` | 待補 |
| DELETE | `/asset-relations/{id}` | 移除依賴關係 | `asset:write` | 待補 |
| GET | `/assets/{id}/work-orders` | 設備維修履歷 | `work_order:read` | 待補 |
| GET | `/assets/{id}/status-history` | 狀態變更歷程 | `asset:read` | 待補 |
| POST | `/assets:bulk-import` | 批次匯入設備（含試跑模式） | `asset:write` | 待補 |
| POST | `/assets/{id}/meters/{meterCode}/readings` | 登錄計量讀數 | `meter:write` | 契約 |
| GET | `/assets/{id}/meters/{meterCode}/readings` | 讀數時序 | `meter:read` | 待補 |
| GET | `/asset-categories` | 設備分類樹 | `asset:read` | 待補 |
| GET | `/asset-models` | 設備型錄 | `asset_model:read` | 契約 |
| POST | `/asset-models` | 新增租戶型錄 | `asset_model:write` | 待補 |
| GET | `/asset-models/{id}/compatibility` | 相容性檢查結果 | `asset_model:read` | 待補 |
| GET | `/attribute-definitions` | 動態欄位定義（前端動態表單用） | `asset:read` | 待補 |
| POST | `/attribute-definitions` | 新增動態欄位 | `tenant:update` | 待補 |

## 5. Maintenance (PM)

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/maintenance-templates` | 保養範本 | `maintenance_plan:read` | 待補 |
| POST | `/maintenance-templates` | 建立範本 | `maintenance_template:write` | 待補 |
| GET | `/maintenance-plans` | PM 計畫清單 | `maintenance_plan:read` | 契約 |
| POST | `/maintenance-plans` | 建立 PM 計畫 | `maintenance_plan:write` | 契約 |
| PATCH | `/maintenance-plans/{id}` | 更新計畫 | `maintenance_plan:write` | 待補 |
| GET | `/maintenance-plans/{id}/preview-schedule` | 試算未來排程（不寫入） | `maintenance_plan:read` | 契約 |
| POST | `/maintenance-plans/{id}/generate-now` | 立即產生下一張工單 | `maintenance_plan:write` | 待補 |
| GET | `/maintenance-occurrences` | 排程執行紀錄（PM 合規率來源） | `maintenance_plan:read` | 待補 |
| POST | `/maintenance-occurrences/{id}/skip` | 跳過本次（需理由） | `maintenance_plan:write` | 待補 |

## 6. Service Catalogue (Soft FM)

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/facilities/{facilityId}/service-items` | 可申請服務（含 `form_schema`） | `service_item:read` | 契約 |
| POST | `/facilities/{facilityId}/service-items` | 建立服務項目 | `service_item:write` | 待補 |
| PATCH | `/service-items/{id}` | 更新服務項目 | `service_item:write` | 待補 |
| DELETE | `/service-items/{id}` | 停用服務項目 | `service_item:write` | 待補 |
| GET | `/service-items/{id}/availability` | 服務可用時段（依 availability 設定） | `service_item:read` | 待補 |

## 7. Work Orders（統一工單）

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/work-orders` | 查詢工單（15 種過濾維度） | `work_order:read` / `read_own` | 契約 |
| POST | `/work-orders` | 建立工單／服務請求 | `work_order:create` | 契約 |
| GET | `/work-orders/{id}` | 詳情（`include=...`） | `work_order:read` | 契約 |
| PATCH | `/work-orders/{id}` | 更新欄位（不含狀態） | `work_order:update` | 契約 |
| POST | `/work-orders/{id}/transitions` | 執行狀態機動作 | 依動作而定 | 契約 |
| GET | `/work-orders/{id}/available-actions` | 目前可執行動作（前端按鈕來源） | `work_order:read` | 契約 |
| GET | `/work-orders/{id}/tasks` | 檢查項目 | `work_order:read` | 待補 |
| PATCH | `/work-orders/{id}/tasks/{taskId}` | 回填檢查結果 | `work_order:execute` | 契約 |
| POST | `/work-orders/{id}/comments` | 新增留言 | `work_order:update` | 待補 |
| POST | `/work-orders/{id}/labor` | 登錄工時 | `work_order:execute` | 待補 |
| POST | `/work-orders/{id}/parts` | 領用備品 | `work_order:execute` | 待補 |
| POST | `/work-orders/{id}/attachments` | 掛附件（前後照片、簽名） | `work_order:update` | 待補 |
| POST | `/work-orders/{id}/satisfaction` | 申請人評價 | 申請人本人 | 待補 |
| POST | `/work-orders:bulk-transition` | 批次派工／批次結案 | `work_order:assign` | 待補 |
| GET | `/work-order-statuses` | 狀態字典（含中英文與分類） | 已登入 | 待補 |
| GET | `/work-order-state-machine` | 狀態機定義（供前端繪流程圖） | `work_order:read` | 待補 |
| GET | `/teams` | 團隊與成員 | `team:read` | 待補 |
| GET | `/teams/{id}/workload` | 團隊負載（派工決策用） | `team:read` | 待補 |
| GET | `/teams/{id}/shifts` | 班表 | `team:read` | 待補 |
| POST | `/teams/{id}/shifts` | 建立班表 | `team:write` | 待補 |
| GET | `/parts` / `/part-stock` | 備品與庫存 | `part:read` | 待補 |
| GET | `/sla-policies` | SLA 政策 | `work_order:read` | 待補 |

## 8. Reservations

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/facilities/{facilityId}/availability` | 多資源可用時段（時間軸資料） | `reservation:read` | 契約 |
| GET | `/facilities/{facilityId}/bookable-resources` | 可預約資源與規則 | `reservation:read` | 待補 |
| POST | `/reservations/holds` | 建立短期佔位（兩階段第一步） | `reservation:create` | 契約 |
| DELETE | `/reservations/holds/{token}` | 主動釋放佔位 | `reservation:create` | 待補 |
| GET | `/reservations` | 查詢預約 | `reservation:read` / `read_own` | 契約 |
| POST | `/reservations` | 建立預約（可含附加服務、可含 RRULE） | `reservation:create` | 契約 |
| GET | `/reservations/{id}` | 詳情（含附加服務與其工單狀態） | `reservation:read` | 契約 |
| PATCH | `/reservations/{id}` | 更改預約 | `reservation:update` | 契約 |
| DELETE | `/reservations/{id}` | 取消預約 | `reservation:update` / `cancel_any` | 契約 |
| POST | `/reservations/{id}/check-in` | 報到 | 使用者本人／管理員 | 契約 |
| POST | `/reservations/{id}/check-out` | 提前離場並釋放時段 | 使用者本人 | 待補 |
| POST | `/reservations/{id}/approve` | 審核通過 | `reservation:approve` | 待補 |
| POST | `/reservations/{id}/reject` | 審核駁回 | `reservation:approve` | 待補 |
| DELETE | `/reservation-series/{recurrenceGroupId}` | 取消整個週期系列 | `reservation:update` | 待補 |
| PATCH | `/bookable-resources/{id}` | 設定預約規則 | `bookable_resource:write` | 待補 |
| GET/POST | `/resource-blackouts` | 封鎖時段（維修、公休、包場） | `blackout:write` | 待補 |

## 9. IoT

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| POST | `/telemetry:batch-ingest` | 批次寫入遙測（機器帳號） | `telemetry:ingest` | 契約 |
| GET | `/devices` | 裝置清單與連線狀態 | `device:read` | 待補 |
| POST | `/devices` | 註冊裝置 | `device:write` | 待補 |
| PATCH | `/devices/{id}` | 更新裝置（含綁定設備／空間） | `device:write` | 待補 |
| GET | `/devices/{id}/points` | 通訊點清單 | `device:read` | 待補 |
| GET | `/telemetry/latest` | 多點最新值（儀表板用，單次批量） | `telemetry:read` | 待補 |
| GET | `/telemetry/series` | 時序查詢（含降採樣 `interval=5m`） | `telemetry:read` | 待補 |
| GET | `/alarms` | 查詢告警（含 `unlinked_only`） | `alarm:read` | 契約 |
| POST | `/alarms/{id}/acknowledge` | 確認告警 | `alarm:acknowledge` | 契約 |
| POST | `/alarms/{id}/work-order` | 由告警補建工單 | `work_order:create` | 契約 |
| POST | `/alarms/{id}/suppress` | 抑制告警（維修期間） | `alarm:acknowledge` | 待補 |
| GET/POST | `/alarm-rules` | 告警規則（含自動建單設定） | `alarm_rule:write` | 待補 |
| POST | `/alarm-rules/{id}/test` | 以歷史資料試跑規則 | `alarm_rule:write` | 待補 |
| POST | `/alarms:reconcile-work-orders` | 批次補串歷史未關聯告警 | `work_order:create` | 待補 |

## 10. Admin

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/users` | 查詢使用者 | `user:read` | 契約 |
| POST | `/users` | 建立使用者（本地帳號／外包） | `user:write` | 待補 |
| PATCH | `/users/{id}` | 更新使用者 | `user:write` | 待補 |
| POST | `/users/{id}/suspend` | 停用 | `user:write` | 待補 |
| GET | `/users/{id}/role-assignments` | 授權清單 | `role:read` | 待補 |
| POST | `/users/{id}/role-assignments` | 指派角色（含 scope） | `role:assign` | 契約 |
| DELETE | `/role-assignments/{id}` | 撤銷授權 | `role:assign` | 待補 |
| GET | `/roles` | 角色（平台 + 租戶自訂） | `role:read` | 待補 |
| POST | `/roles` | 建立自訂角色 | `role:write` | 待補 |
| GET | `/permissions` | 權限字典（權限矩陣 UI 用） | `role:read` | 待補 |
| GET | `/audit-log` | 稽核日誌 | `audit:read` | 契約 |
| POST | `/audit-log:export` | 匯出稽核（非同步產檔） | `audit:export` | 待補 |
| GET | `/skills` / `/users/{id}/skills` | 技能與證照（含到期提醒） | `team:read` | 待補 |
| POST | `/uploads/presign` | 取得檔案直傳預簽網址 | 已登入 | 待補 |
| GET | `/notifications` | 站內通知收件匣 | 已登入 | 待補 |
| POST | `/notifications/{id}/read` | 標記已讀 | 已登入 | 待補 |
| GET | `/webhooks` / POST | 客戶端 webhook 訂閱（事件外送） | `tenant:update` | 待補 |

## 11. Reporting

| Method | Path | 說明 | 權限 | 狀態 |
|---|---|---|---|---|
| GET | `/reports/facility-dashboard` | 設施儀表板彙總（單次請求） | `report:read` | 契約 |
| GET | `/reports/sla-compliance` | SLA 達成率（多維彙總） | `report:read` | 契約 |
| GET | `/reports/group-rollup` | 集團跨組織彙總（依 org 子樹） | `report:read` | 待補 |
| GET | `/reports/asset-reliability` | MTBF / MTTR / 故障 Top N | `report:read` | 待補 |
| GET | `/reports/pm-compliance` | PM 準時完成率 | `report:read` | 待補 |
| GET | `/reports/space-utilization` | 空間使用率與 No-show | `report:read` | 待補 |
| GET | `/reports/service-volume` | 軟性服務量與成本（可 chargeback） | `report:read` | 待補 |
| POST | `/reports/{reportCode}:export` | 匯出 xlsx/csv（非同步） | `report:export` | 待補 |

---

## 領域事件（Outbox → 訂閱者）

第一階段以資料庫 outbox + worker 輪詢實作；第二階段同一批事件原封不動轉送 Kafka，
生產端與訂閱端契約不變。

| 事件 | 觸發時機 | 主要訂閱者 |
|---|---|---|
| `work_order.created` | 工單建立（含 IoT 自動建單） | 通知、報表 |
| `work_order.assigned` | 派工 | 推播給負責人、SLA 計時 |
| `work_order.status_changed` | 任何狀態變更 | 稽核、報表 |
| `work_order.completed` | 完成 | 通知申請人、滿意度邀請、資產狀態回寫 |
| `work_order.sla_breached` | SLA 逾期 | 升級通知 |
| `reservation.confirmed` | 預約成立 | **附加服務工單 fan-out**、行事曆同步 |
| `reservation.cancelled` | 預約取消 | 取消對應服務工單、釋放班表 |
| `reservation.no_show` | 未報到自動釋放 | 空間使用率報表 |
| `alarm.raised` | 告警產生 | 自動建單、通知 |
| `alarm.cleared` | 告警解除 | 關聯工單提示 |
| `asset.status_changed` | 設備狀態變更 | BIM 檢視、儀表板 |
| `maintenance.occurrence_generated` | PM 產單 | 派工排程 |
| `directory.sync_completed` | 目錄同步完成 | 管理員摘要 |

## 背景作業（Workers）

| 作業 | 頻率 | 職責 |
|---|---|---|
| `outbox-relay` | 每 2 秒 | 撈取 outbox（`FOR UPDATE SKIP LOCKED`）→ 執行 side effects／發通知 |
| `pm-generator` | 每小時 | 依 RRULE / 計量門檻產生 `maintenance_occurrences` 與工單 |
| `sla-watchdog` | 每分鐘 | 掃描 `resolution_due_at`，標記 `AT_RISK` / 觸發 `BREACH_SLA` |
| `reservation-janitor` | 每分鐘 | 過期 hold 失效、未報到轉 `NO_SHOW`、釋放時段 |
| `device-heartbeat` | 每 5 分鐘 | 偵測離線裝置並依規則產生 `DEVICE_OFFLINE` 告警 |
| `directory-sync` | 依 IdP cron | AD/Entra 使用者與群組同步、角色自動增撤 |
| `partition-maintainer` | 每日 | 預建下 3 個月的 audit / telemetry 分區，歸檔逾期分區 |
| `rollup-refresher` | 每 15 分鐘 | 更新節點健康度、使用率、設備 health_score 快取 |
| `notification-dispatcher` | 每 10 秒 | 送出 email / push / webhook，指數退避重試 |
