# SecuAgent Design System

> 智微軟體公司 · SecuAgent
> **Intelligent Security, Micro Precision**

A brand-first design system for SecuAgent, a security-software company. This system encodes the brand's identity — a navy/teal palette, Montserrat + Noto Sans TC type, an angular shield mark — into tokens, reusable components, and a marketing-site UI kit that design agents can build against.

---

## Sources

The system was derived from a single provided asset:

- `uploads/image.png` — the official SecuAgent Corporate Identity System sheet (企業識別系統). It defines the logo and its color variants (Full color / Mono / Reverse / Teal), the core palette, standard typefaces, the shield pattern texture, and application mockups (business card, letterhead, envelope, lanyard/ID, notebook, website on tablet + phone).

There was **no codebase or Figma file**. Colors, fonts, and logo forms are lifted verbatim from the sheet; the component library and UI kit are authored to match the brand's visual language (they are new, brand-consistent constructions, not recreations of an existing product build).

---

## Brand at a glance

| | |
|---|---|
| **Name** | SecuAgent · 智微軟體公司 ("Intelligent Micro Software Co.") |
| **Tagline** | Intelligent Security, Micro Precision |
| **Primary Navy** | `#1B3F67` |
| **Tech Teal** | `#008C99` |
| **Accent Gray** | `#6C757D` |
| **Latin type** | Montserrat |
| **CJK type** | Noto Sans TC (思源黑體 / Source Han Sans) |

The mark is an angular **shield** enclosing an interlocked "S/A" monogram — communicating protection (security) and precision (the sharp, geometric cuts).

---

## CONTENT FUNDAMENTALS

How SecuAgent writes.

- **Bilingual, Traditional-Chinese first.** Primary market copy leads in Traditional Chinese (智微軟體) with an English lockup beneath. English is title-cased and concise.
- **Voice:** confident, precise, understated. Security vendors over-promise; SecuAgent's tone is *calm authority* — it states capability without hype or fear-mongering.
- **The tagline formula is "adjective noun, adjective noun":** *Intelligent Security, Micro Precision* (智慧安全，微致精準). Copy echoes this balanced, paired cadence — two crisp clauses, parallel structure.
- **Casing:** Montserrat headings in **Title Case** or short **UPPERCASE eyebrows** (tracked, `--ls-caps`). Body sentence case. Never ALL-CAPS body copy.
- **Person:** speak to the customer as **"you"**; refer to the company as **"we"** / SecuAgent. Product-benefit framing over feature-listing ("you stay protected" rather than "the system logs events").
- **No emoji.** This is enterprise security — tone is professional. Iconography carries visual accent instead (see ICONOGRAPHY).
- **Numbers & precision:** lean into "micro precision" — exact figures ("99.99% uptime", "< 5 ms detection") read as more credible than vague superlatives.
- **Example copy:**
  - Eyebrow: `ENTERPRISE SECURITY` / `企業級防護`
  - Headline: `Intelligent Security, Micro Precision`
  - Sub: `SecuAgent detects, isolates, and resolves threats before they reach you — with precision measured in milliseconds.`
  - CTA: `Get protected` · `Book a demo` · `免費試用`

---

## VISUAL FOUNDATIONS

- **Color vibe:** cool, corporate, trustworthy. Deep **navy** is the anchor (backgrounds, headings, primary buttons); **teal** is the single energetic accent (links, highlights, secondary CTAs, active states); **gray** is structural (borders, muted text). White space is generous. Never warm; never pastel.
- **Primary vs accent discipline:** navy dominates, teal punctuates. On a page, teal should feel scarce — a highlight, not a fill. Avoid navy+teal 50/50 splits.
- **Type:** Montserrat for all Latin UI/display — geometric, even, slightly wide; headings are **bold (700) / extrabold (800)** with tight tracking (`--ls-tight`). Noto Sans TC for Chinese, weight-matched. Body is regular 400 at 16px, line-height 1.6.
- **Backgrounds:** predominantly flat white or `--gray-50`. Dark sections use `--navy-800/900`. **The shield pattern** (`assets/pattern.png`) is the signature texture — used low-opacity as a subtle field on dark hero/footer bands, never at full strength behind text. No photographic gradients, no bluish-purple gradients. A restrained navy→navy-900 flat-ish gradient is acceptable on hero bands only.
- **Imagery:** cool-toned, desaturated, professional (product-on-device, abstract tech, office). Blue/teal cast preferred. No warm filters, no heavy grain.
- **Corner radii:** restrained and geometric — cards/inputs `8px` (`--radius-md`), buttons `5–8px`, pills only for badges/tags. The brand is angular (the shield); avoid overly round, playful radii.
- **Cards:** white surface, `1px` `--border-subtle`, `--radius-md`, `--shadow-sm`; hover lifts to `--shadow-md`. Clean and light — not heavy drop-shadows.
- **Borders:** hairline `1px` grays. Focus uses a `3px` teal ring (`--focus-ring`), not a color change alone.
- **Shadows:** cool, **navy-tinted** (`rgba(14,33,56,…)`), soft and diffuse. No pure-black or colored glows.
- **Animation:** subtle and quick — `120–320ms`, `ease-standard` / `ease-out`. Fades and small translate/lift on hover. **No bounce, no spring, no attention-seeking motion.** Precision = economy of movement.
- **Hover states:** buttons darken (navy→navy-800; teal→teal-800); links teal→teal-800; cards raise shadow + `translateY(-2px)`. **Press:** darken one more step (active) and/or `translateY(0)`; no scale-shrink gimmicks except a tiny `0.99` on primary buttons if desired.
- **Transparency/blur:** sparing. Sticky header may use a `blur(8px)` translucent white. The shield pattern uses opacity. Otherwise surfaces are solid.
- **Layout:** `1200px` max container, generous section padding (`--space-20/24`). Left-aligned headings, clear grid. Fixed/sticky header at `72px`.

---

## ICONOGRAPHY

- **No proprietary icon set was provided.** The brand sheet shows only the shield logo mark; the website mockup uses generic simple line/duotone feature icons.
- **Substitution (FLAGGED):** this system uses **[Lucide](https://lucide.dev)** via CDN as the icon set. Lucide's thin, even, geometric strokes (2px, rounded joins) match SecuAgent's "micro precision," angular aesthetic. Icons are rendered in `--navy-700` or `--teal-700`. → *If SecuAgent has an official icon set, please provide it and this will be swapped.*
- **Logo mark** is the one bespoke glyph: use `assets/logo-icon*.png` (never redraw it). Variants: full-color (`logo-icon.png` / transparent), reverse white (`logo-icon-reverse.png`), teal (`logo-icon-teal.png`), full lockup (`logo-lockup.png`).
- **No emoji.** No Unicode-as-icon hacks. Use Lucide glyphs or the shield mark.
- **Feature-tile treatment:** icons often sit in a soft rounded square (teal-100 or navy-50 background, `--radius-md`), glyph in teal/navy — as seen in the website mockup's feature cards.

---

## Index / manifest

**Root**
- `styles.css` — global entry (import list only)
- `readme.md` — this file
- `SKILL.md` — Agent-Skills-compatible entry

**tokens/**
- `fonts.css` · `colors.css` · `typography.css` · `layout.css` · `base.css`

**assets/**
- `logo-lockup.png` — full vertical lockup (icon + 智微軟體公司 / SecuAgent + tagline)
- `logo-icon.png` / `logo-icon-transparent.png` — full-color shield
- `logo-icon-reverse.png` — white shield (for dark backgrounds)
- `logo-icon-teal.png` — white shield on teal tile
- `pattern.png` — repeating shield texture

**components/** (namespace resolved by the compiler — see `check_design_system`)
- `forms/` — Button, IconButton, Input, Textarea, Select, Checkbox
- `data-display/` — Card, Badge, Tag, FeatureTile, Stat
- `feedback/` — Alert
- `brand/` — Logo

**ui_kits/**
- `website/` — SecuAgent marketing site (hero, features, product, pricing, footer) as an interactive click-through

---

## Intentional additions

Because no source component inventory existed, a standard brand-sized set was authored. Two brand-specific additions:
- **Logo** — wraps the official mark assets so consumers never redraw it.
- **FeatureTile** — the icon-in-soft-square feature card seen in the website mockup; core to the brand's marketing layout.
