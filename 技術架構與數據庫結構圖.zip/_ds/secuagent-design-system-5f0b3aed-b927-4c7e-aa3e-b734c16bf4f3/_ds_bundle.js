/* @ds-bundle: {"format":4,"namespace":"SecuAgentDesignSystem_5f0b3a","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"FeatureTile","sourcePath":"components/data-display/FeatureTile.jsx"},{"name":"Stat","sourcePath":"components/data-display/Stat.jsx"},{"name":"Tag","sourcePath":"components/data-display/Tag.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"487185f4aff4","components/data-display/Badge.jsx":"11af44c28b25","components/data-display/Card.jsx":"e764fdd4a53e","components/data-display/FeatureTile.jsx":"2431f4c0831e","components/data-display/Stat.jsx":"e816b4d6b457","components/data-display/Tag.jsx":"e76e066f8a0a","components/feedback/Alert.jsx":"627efe18d84c","components/forms/Button.jsx":"df661aae5d86","components/forms/Checkbox.jsx":"ec689a54e24a","components/forms/IconButton.jsx":"c93f61b4e8f2","components/forms/Input.jsx":"c982b2e1897d","components/forms/Select.jsx":"c2b268b3141e","components/forms/Textarea.jsx":"9381b3092d17","ui_kits/website/Features.jsx":"a180523ce0e9","ui_kits/website/Footer.jsx":"138422be1378","ui_kits/website/Header.jsx":"61430e572b0a","ui_kits/website/Hero.jsx":"43f184c999b2","ui_kits/website/Pricing.jsx":"af4f103ee5a6","ui_kits/website/Product.jsx":"5b05c8ee54cb"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SecuAgentDesignSystem_5f0b3a = window.SecuAgentDesignSystem_5f0b3a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecuAgent Logo — renders the official mark (never redrawn).
 * Point `basePath` at wherever the /assets folder is served from.
 */
function Logo({
  variant = 'full',
  // 'full' (icon+wordmark) | 'icon' | 'reverse' | 'teal'
  height,
  // px; sensible defaults per variant
  basePath = 'assets/',
  showWordmark,
  // for variant 'icon' family — force wordmark on/off
  onDark = false,
  style = {},
  ...rest
}) {
  const files = {
    full: 'logo-lockup.png',
    icon: 'logo-icon-transparent.png',
    reverse: 'logo-icon-reverse.png',
    teal: 'logo-icon-teal.png'
  };
  const src = basePath + (files[variant] || files.full);
  const h = height || (variant === 'full' ? 96 : 40);

  // Inline lockup (icon + text wordmark) — for headers where the vertical PNG is too tall
  if (variant === 'wordmark' || showWordmark) {
    const iconSrc = basePath + (onDark ? files.reverse : files.icon);
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 10,
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("img", {
      src: iconSrc,
      alt: "SecuAgent",
      style: {
        height: h,
        width: 'auto',
        display: 'block'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--fw-extrabold)',
        fontSize: h * 0.5,
        letterSpacing: '-0.01em',
        color: onDark ? '#fff' : 'var(--navy-700)'
      }
    }, "SecuAgent"));
  }
  return /*#__PURE__*/React.createElement("img", _extends({
    src: src,
    alt: "SecuAgent",
    style: {
      height: h,
      width: 'auto',
      display: 'block',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Badge — small status pill. */
function Badge({
  children,
  variant = 'neutral',
  style = {},
  ...rest
}) {
  const variants = {
    neutral: {
      bg: 'var(--gray-100)',
      color: 'var(--gray-700)'
    },
    navy: {
      bg: 'var(--navy-100)',
      color: 'var(--navy-700)'
    },
    teal: {
      bg: 'var(--teal-100)',
      color: 'var(--teal-800)'
    },
    success: {
      bg: 'var(--success-bg)',
      color: 'var(--success)'
    },
    warning: {
      bg: 'var(--warning-bg)',
      color: 'var(--warning)'
    },
    danger: {
      bg: 'var(--danger-bg)',
      color: 'var(--danger)'
    },
    solid: {
      bg: 'var(--navy-700)',
      color: '#fff'
    }
  };
  const v = variants[variant] || variants.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      padding: '3px 10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-xs)',
      fontWeight: 'var(--fw-semibold)',
      lineHeight: 1.4,
      letterSpacing: '0.01em',
      color: v.color,
      background: v.bg,
      borderRadius: 'var(--radius-pill)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecuAgent Card — white surface, hairline border, soft navy shadow.
 * Set `interactive` for hover lift.
 */
function Card({
  children,
  padding = 'var(--space-6)',
  interactive = false,
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-sm)',
      padding,
      transition: 'box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)',
      transform: hover ? 'translateY(-2px)' : 'translateY(0)',
      cursor: interactive ? 'pointer' : 'default',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/FeatureTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecuAgent FeatureTile — icon-in-soft-square marketing feature card.
 * The signature marketing block from the brand's website mockup.
 */
function FeatureTile({
  icon,
  title,
  children,
  accent = 'teal',
  href,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const accents = {
    teal: {
      bg: 'var(--teal-100)',
      fg: 'var(--teal-700)'
    },
    navy: {
      bg: 'var(--navy-100)',
      fg: 'var(--navy-700)'
    }
  };
  const a = accents[accent] || accents.teal;
  const Wrapper = href ? 'a' : 'div';
  return /*#__PURE__*/React.createElement(Wrapper, _extends({
    href: href,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      textDecoration: 'none',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-6)',
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-sm)',
      transform: hover ? 'translateY(-2px)' : 'translateY(0)',
      transition: 'box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 52,
      height: 52,
      borderRadius: 'var(--radius-md)',
      background: a.bg,
      color: a.fg,
      marginBottom: 'var(--space-4)'
    }
  }, icon), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--fs-h4)',
      fontWeight: 'var(--fw-bold)',
      color: 'var(--text-heading)',
      marginBottom: 'var(--space-2)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--fs-body)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--lh-body)',
      margin: 0
    }
  }, children));
}
Object.assign(__ds_scope, { FeatureTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/FeatureTile.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Stat — big number + label, for metric strips ("micro precision" proof points). */
function Stat({
  value,
  label,
  sub,
  align = 'left',
  onDark = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-h1)',
      fontWeight: 'var(--fw-extrabold)',
      letterSpacing: 'var(--ls-tight)',
      lineHeight: 1.05,
      color: onDark ? '#fff' : 'var(--navy-700)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-semibold)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--ls-caps)',
      color: onDark ? 'var(--teal-300)' : 'var(--teal-700)'
    }
  }, label), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4,
      fontSize: 'var(--fs-sm)',
      color: onDark ? 'var(--navy-200)' : 'var(--text-muted)'
    }
  }, sub));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Stat.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Tag — outlined/removable label chip. */
function Tag({
  children,
  removable = false,
  onRemove,
  variant = 'default',
  style = {},
  ...rest
}) {
  const variants = {
    default: {
      bg: '#fff',
      color: 'var(--navy-700)',
      border: 'var(--border-default)'
    },
    teal: {
      bg: 'var(--teal-100)',
      color: 'var(--teal-800)',
      border: 'var(--teal-200)'
    }
  };
  const v = variants[variant] || variants.default;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '4px 10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-medium)',
      color: v.color,
      background: v.bg,
      border: `1px solid ${v.border}`,
      borderRadius: 'var(--radius-sm)',
      ...style
    }
  }, rest), children, removable && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: onRemove,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 16,
      height: 16,
      padding: 0,
      border: 'none',
      background: 'transparent',
      color: 'currentColor',
      cursor: 'pointer',
      opacity: 0.6,
      borderRadius: 'var(--radius-xs)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "10",
    height: "10",
    viewBox: "0 0 10 10"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l8 8M9 1l-8 8",
    stroke: "currentColor",
    strokeWidth: "1.5",
    strokeLinecap: "round"
  }))));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Alert — inline status message with left accent + optional dismiss. */
function Alert({
  children,
  title,
  variant = 'info',
  onClose,
  style = {},
  ...rest
}) {
  const variants = {
    info: {
      bg: 'var(--teal-100)',
      border: 'var(--teal-700)',
      fg: 'var(--teal-900)'
    },
    success: {
      bg: 'var(--success-bg)',
      border: 'var(--success)',
      fg: '#134c33'
    },
    warning: {
      bg: 'var(--warning-bg)',
      border: 'var(--warning)',
      fg: '#6b4d00'
    },
    danger: {
      bg: 'var(--danger-bg)',
      border: 'var(--danger)',
      fg: '#7d2820'
    }
  };
  const v = variants[variant] || variants.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '12px',
      padding: '12px 14px',
      background: v.bg,
      borderLeft: `4px solid ${v.border}`,
      borderRadius: 'var(--radius-sm)',
      color: v.fg,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-sm)',
      lineHeight: 'var(--lh-snug)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--fw-bold)',
      marginBottom: children ? 2 : 0
    }
  }, title), children), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      border: 'none',
      background: 'transparent',
      color: 'currentColor',
      cursor: 'pointer',
      opacity: 0.6,
      padding: 2,
      lineHeight: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l10 10M11 1L1 11",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round"
  }))));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecuAgent Button — primary action element.
 * Navy is the primary fill; teal is the accent; ghost/outline for secondary.
 */
function Button({
  children,
  variant = 'primary',
  // 'primary' | 'accent' | 'secondary' | 'ghost' | 'danger'
  size = 'md',
  // 'sm' | 'md' | 'lg'
  block = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '7px 14px',
      fontSize: 'var(--fs-sm)',
      gap: '6px',
      radius: 'var(--radius-sm)'
    },
    md: {
      padding: '10px 20px',
      fontSize: 'var(--fs-body)',
      gap: '8px',
      radius: 'var(--radius-md)'
    },
    lg: {
      padding: '14px 28px',
      fontSize: 'var(--fs-lg)',
      gap: '10px',
      radius: 'var(--radius-md)'
    }
  };
  const variants = {
    primary: {
      bg: 'var(--navy-700)',
      color: '#fff',
      border: 'transparent',
      hover: 'var(--navy-800)'
    },
    accent: {
      bg: 'var(--teal-700)',
      color: '#fff',
      border: 'transparent',
      hover: 'var(--teal-800)'
    },
    secondary: {
      bg: 'transparent',
      color: 'var(--navy-700)',
      border: 'var(--navy-700)',
      hover: 'var(--navy-50)'
    },
    ghost: {
      bg: 'transparent',
      color: 'var(--navy-700)',
      border: 'transparent',
      hover: 'var(--gray-100)'
    },
    danger: {
      bg: 'var(--danger)',
      color: '#fff',
      border: 'transparent',
      hover: '#a83a31'
    }
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  const [hover, setHover] = React.useState(false);
  const bg = variant === 'secondary' || variant === 'ghost' ? hover ? v.hover : v.bg : hover ? v.hover : v.bg;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: block ? 'flex' : 'inline-flex',
      width: block ? '100%' : 'auto',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      padding: s.padding,
      fontFamily: 'var(--font-sans)',
      fontSize: s.fontSize,
      fontWeight: 'var(--fw-semibold)',
      lineHeight: 1,
      letterSpacing: '0.01em',
      color: v.color,
      background: bg,
      border: `1.5px solid ${v.border === 'transparent' ? 'transparent' : v.border}`,
      borderRadius: s.radius,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-standard)',
      transform: hover && !disabled ? 'translateY(-1px)' : 'translateY(0)',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Checkbox — teal-filled when checked. */
function Checkbox({
  label,
  id,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  style = {},
  ...rest
}) {
  const autoId = React.useId ? React.useId() : undefined;
  const fieldId = id || autoId;
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const on = isControlled ? checked : internal;
  const handle = e => {
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e);
  };
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-body)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 20,
      height: 20,
      flexShrink: 0,
      borderRadius: 'var(--radius-xs)',
      border: `1.5px solid ${on ? 'var(--teal-700)' : 'var(--border-strong)'}`,
      background: on ? 'var(--teal-700)' : '#fff',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2.5 6.2L4.8 8.5L9.5 3.5",
    stroke: "#fff",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "checkbox",
    checked: on,
    defaultChecked: defaultChecked,
    onChange: handle,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecuAgent IconButton — square button for a single glyph (toolbar, close, nav).
 * Pass a Lucide <i data-lucide> or SVG as children.
 */
function IconButton({
  children,
  variant = 'ghost',
  // 'ghost' | 'solid' | 'accent' | 'outline'
  size = 'md',
  // 'sm' | 'md' | 'lg'
  disabled = false,
  ariaLabel,
  onClick,
  style = {},
  ...rest
}) {
  const dims = {
    sm: 32,
    md: 40,
    lg: 48
  };
  const d = dims[size] || dims.md;
  const variants = {
    ghost: {
      bg: 'transparent',
      color: 'var(--navy-700)',
      border: 'transparent',
      hover: 'var(--gray-100)'
    },
    solid: {
      bg: 'var(--navy-700)',
      color: '#fff',
      border: 'transparent',
      hover: 'var(--navy-800)'
    },
    accent: {
      bg: 'var(--teal-700)',
      color: '#fff',
      border: 'transparent',
      hover: 'var(--teal-800)'
    },
    outline: {
      bg: '#fff',
      color: 'var(--navy-700)',
      border: 'var(--border-default)',
      hover: 'var(--gray-50)'
    }
  };
  const v = variants[variant] || variants.ghost;
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": ariaLabel,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: d,
      height: d,
      color: v.color,
      background: hover && !disabled ? v.hover : v.bg,
      border: `1.5px solid ${v.border === 'transparent' ? 'transparent' : v.border}`,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--dur-fast) var(--ease-standard)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecuAgent Input — labeled text field with teal focus ring.
 */
function Input({
  label,
  id,
  type = 'text',
  placeholder,
  value,
  defaultValue,
  onChange,
  hint,
  error,
  disabled = false,
  required = false,
  iconLeft = null,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const autoId = React.useId ? React.useId() : undefined;
  const fieldId = id || autoId;
  const borderColor = error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-sans)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger)',
      marginLeft: 2
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: iconLeft ? '0 12px' : '0',
      background: disabled ? 'var(--gray-100)' : '#fff',
      border: `1.5px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focus && !error ? 'var(--focus-ring)' : 'none',
      transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)'
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      color: 'var(--text-muted)'
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      padding: '10px 12px',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-body)',
      paddingLeft: iconLeft ? 0 : '12px'
    }
  }, rest))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Select — native dropdown styled to match Input. */
function Select({
  label,
  id,
  value,
  defaultValue,
  onChange,
  options = [],
  placeholder,
  hint,
  error,
  disabled = false,
  required = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const autoId = React.useId ? React.useId() : undefined;
  const fieldId = id || autoId;
  const borderColor = error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)';
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-sans)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger)',
      marginLeft: 2
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      width: '100%',
      padding: '10px 40px 10px 12px',
      background: disabled ? 'var(--gray-100)' : '#fff',
      border: `1.5px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focus && !error ? 'var(--focus-ring)' : 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: value || defaultValue ? 'var(--text-body)' : 'var(--text-muted)',
      outline: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)'
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--text-muted)',
      borderLeft: '5px solid transparent',
      borderRight: '5px solid transparent',
      borderTop: '6px solid var(--gray-500)'
    }
  })), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** SecuAgent Textarea — multi-line field, matches Input styling. */
function Textarea({
  label,
  id,
  placeholder,
  value,
  defaultValue,
  onChange,
  hint,
  error,
  disabled = false,
  required = false,
  rows = 4,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const autoId = React.useId ? React.useId() : undefined;
  const fieldId = id || autoId;
  const borderColor = error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-heading)',
      fontFamily: 'var(--font-sans)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger)',
      marginLeft: 2
    }
  }, "*")), /*#__PURE__*/React.createElement("textarea", _extends({
    id: fieldId,
    rows: rows,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      padding: '10px 12px',
      resize: 'vertical',
      background: disabled ? 'var(--gray-100)' : '#fff',
      border: `1.5px solid ${borderColor}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focus && !error ? 'var(--focus-ring)' : 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-body)',
      outline: 'none',
      transition: 'border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)'
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Features.jsx
try { (() => {
// SecuAgent website — Stats strip + Features
(function () {
  const {
    Stat,
    FeatureTile
  } = window.SecuAgentDesignSystem_5f0b3a;
  function Stats() {
    const items = [['99.99%', 'Uptime SLA'], ['< 5ms', 'Median detection'], ['24/7', 'SOC monitoring'], ['150+', 'Enterprises protected']];
    return /*#__PURE__*/React.createElement("section", {
      style: {
        borderTop: '1px solid var(--border-subtle)',
        borderBottom: '1px solid var(--border-subtle)',
        background: '#fff'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '40px 32px',
        display: 'grid',
        gridTemplateColumns: 'repeat(4,1fr)',
        gap: 24
      }
    }, items.map(([v, l]) => /*#__PURE__*/React.createElement(Stat, {
      key: l,
      value: v,
      label: l,
      align: "center"
    }))));
  }
  function Features() {
    const feats = [['shield-check', 'Threat isolation', 'Contain malicious activity in milliseconds — quarantined before it can spread across your network.', 'teal'], ['scan-eye', 'Continuous detection', 'Behavioral analysis watches every endpoint around the clock, flagging anomalies the moment they appear.', 'navy'], ['zap', 'Auto-remediation', 'Resolve common threats automatically with policy-driven playbooks — no analyst required.', 'teal'], ['bar-chart-3', 'Unified visibility', 'One console for your entire fleet: posture, alerts, and audit trails in a single pane of glass.', 'navy'], ['git-branch', 'Zero-trust access', 'Verify every request. Grant least-privilege access scoped to device, identity, and context.', 'teal'], ['file-check-2', 'Compliance built in', 'SOC 2, ISO 27001, and GDPR reporting generated continuously from live evidence.', 'navy']];
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--gray-50)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '88px 32px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        maxWidth: 640,
        margin: '0 auto 48px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "sa-eyebrow"
    }, "Platform"), /*#__PURE__*/React.createElement("h2", {
      style: {
        fontSize: 'var(--fs-h1)',
        fontWeight: 800,
        margin: '14px 0 14px',
        color: 'var(--navy-900)'
      }
    }, "Protection, engineered for precision"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 'var(--fs-lg)',
        color: 'var(--text-muted)',
        lineHeight: 1.6
      }
    }, "Every layer of the SecuAgent platform works to the same standard: detect fast, respond faster, and never get in your team's way.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 24
      }
    }, feats.map(([ic, t, d, a]) => /*#__PURE__*/React.createElement(FeatureTile, {
      key: t,
      accent: a,
      title: t,
      icon: /*#__PURE__*/React.createElement("i", {
        "data-lucide": ic,
        style: {
          width: 26,
          height: 26
        }
      })
    }, d)))));
  }
  window.Stats = Stats;
  window.Features = Features;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Features.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
// SecuAgent website — Footer + demo modal
(function () {
  const {
    Logo,
    Input,
    Button,
    Select
  } = window.SecuAgentDesignSystem_5f0b3a;
  const FB = '../../assets/';
  function Footer() {
    const cols = [['Product', ['Platform', 'Detection', 'Remediation', 'Zero-trust', 'Pricing']], ['Company', ['About', 'Careers', 'Newsroom', 'Contact']], ['Resources', ['Docs', 'Security', 'Compliance', 'Status']]];
    return /*#__PURE__*/React.createElement("footer", {
      style: {
        background: 'var(--navy-900)',
        color: '#fff'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '64px 32px 32px',
        display: 'grid',
        gridTemplateColumns: '1.4fr repeat(3,1fr)',
        gap: 40
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Logo, {
      variant: "wordmark",
      height: 32,
      basePath: FB,
      onDark: true
    }), /*#__PURE__*/React.createElement("p", {
      style: {
        color: 'var(--navy-200)',
        fontSize: 'var(--fs-sm)',
        lineHeight: 1.6,
        margin: '16px 0 0',
        maxWidth: 260
      }
    }, "Intelligent Security, Micro Precision. \u667A\u5FAE\u8EDF\u9AD4\u516C\u53F8 \u2014 protecting enterprise fleets worldwide.")), cols.map(([h, links]) => /*#__PURE__*/React.createElement("div", {
      key: h
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 'var(--fs-xs)',
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.14em',
        color: 'var(--teal-300)',
        marginBottom: 16
      }
    }, h), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, links.map(l => /*#__PURE__*/React.createElement("a", {
      key: l,
      href: "#",
      style: {
        color: 'var(--navy-200)',
        fontSize: 'var(--fs-sm)'
      }
    }, l)))))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: '1px solid var(--navy-800)',
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '20px 32px',
        display: 'flex',
        justifyContent: 'space-between',
        color: 'var(--navy-300)',
        fontSize: 'var(--fs-xs)'
      }
    }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 SecuAgent \xB7 \u667A\u5FAE\u8EDF\u9AD4\u516C\u53F8"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        color: 'var(--navy-300)'
      }
    }, "Privacy"), /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        color: 'var(--navy-300)'
      }
    }, "Terms"), /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        color: 'var(--navy-300)'
      }
    }, "Cookies"))));
  }
  function DemoModal({
    open,
    onClose
  }) {
    const [sent, setSent] = React.useState(false);
    React.useEffect(() => {
      if (open) setSent(false);
    }, [open]);
    if (!open) return null;
    return /*#__PURE__*/React.createElement("div", {
      onClick: onClose,
      style: {
        position: 'fixed',
        inset: 0,
        zIndex: 100,
        background: 'rgba(14,33,56,0.55)',
        backdropFilter: 'blur(3px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      onClick: e => e.stopPropagation(),
      style: {
        width: 460,
        maxWidth: '100%',
        background: '#fff',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-xl)',
        padding: 32
      }
    }, sent ? /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        padding: '20px 0'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 56,
        height: 56,
        borderRadius: 999,
        background: 'var(--teal-100)',
        color: 'var(--teal-700)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto 16px'
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": "check",
      style: {
        width: 28,
        height: 28
      }
    })), /*#__PURE__*/React.createElement("h3", {
      style: {
        fontSize: 'var(--fs-h3)',
        fontWeight: 700,
        color: 'var(--navy-900)',
        margin: '0 0 8px'
      }
    }, "You're all set"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: 'var(--text-muted)',
        margin: '0 0 24px'
      }
    }, "Our team will reach out within one business day to schedule your demo."), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      block: true,
      onClick: onClose
    }, "Done")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 20
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
      style: {
        fontSize: 'var(--fs-h3)',
        fontWeight: 700,
        color: 'var(--navy-900)',
        margin: 0
      }
    }, "Book a demo"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: 'var(--text-muted)',
        fontSize: 'var(--fs-sm)',
        margin: '4px 0 0'
      }
    }, "See SecuAgent protect a live fleet.")), /*#__PURE__*/React.createElement("button", {
      onClick: onClose,
      "aria-label": "Close",
      style: {
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        color: 'var(--text-muted)',
        padding: 4
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": "x",
      style: {
        width: 20,
        height: 20
      }
    }))), /*#__PURE__*/React.createElement("form", {
      onSubmit: e => {
        e.preventDefault();
        setSent(true);
        setTimeout(() => window.lucide && window.lucide.createIcons(), 30);
      },
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Work email",
      type: "email",
      placeholder: "you@company.com",
      required: true
    }), /*#__PURE__*/React.createElement(Select, {
      label: "Company size",
      placeholder: "Select\u2026",
      options: ['1–50', '51–500', '500+'],
      required: true
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      type: "submit",
      block: true
    }, "Request demo")))));
  }
  window.Footer = Footer;
  window.DemoModal = DemoModal;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
// SecuAgent website — Header
(function () {
  const {
    Button,
    Logo
  } = window.SecuAgentDesignSystem_5f0b3a;
  const B = '../../assets/';
  function Header({
    onDemo
  }) {
    const [scrolled, setScrolled] = React.useState(false);
    React.useEffect(() => {
      const el = document.querySelector('.kit-scroll');
      const onScroll = () => setScrolled((el ? el.scrollTop : window.scrollY) > 8);
      (el || window).addEventListener('scroll', onScroll);
      return () => (el || window).removeEventListener('scroll', onScroll);
    }, []);
    const nav = ['Product', 'Solutions', 'Pricing', 'Resources'];
    return /*#__PURE__*/React.createElement("header", {
      style: {
        position: 'sticky',
        top: 0,
        zIndex: 50,
        height: 'var(--header-height)',
        display: 'flex',
        alignItems: 'center',
        background: scrolled ? 'rgba(255,255,255,0.85)' : '#fff',
        backdropFilter: scrolled ? 'blur(10px)' : 'none',
        borderBottom: `1px solid ${scrolled ? 'var(--border-subtle)' : 'transparent'}`,
        transition: 'background var(--dur-base), border-color var(--dur-base)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '0 32px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement(Logo, {
      variant: "wordmark",
      height: 32,
      basePath: B
    }), /*#__PURE__*/React.createElement("nav", {
      style: {
        display: 'flex',
        gap: 30,
        alignItems: 'center'
      }
    }, nav.map(n => /*#__PURE__*/React.createElement("a", {
      key: n,
      href: "#",
      style: {
        fontSize: 'var(--fs-sm)',
        fontWeight: 'var(--fw-semibold)',
        color: 'var(--navy-800)',
        letterSpacing: '0.01em'
      }
    }, n))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        fontSize: 'var(--fs-sm)',
        fontWeight: 'var(--fw-semibold)',
        color: 'var(--navy-800)'
      }
    }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "sm",
      onClick: onDemo
    }, "Book a demo"))));
  }
  window.Header = Header;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
// SecuAgent website — Hero
(function () {
  const {
    Button,
    Badge
  } = window.SecuAgentDesignSystem_5f0b3a;
  function Hero({
    onDemo
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'linear-gradient(180deg, var(--navy-50) 0%, #fff 70%)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '80px 32px 72px',
        display: 'grid',
        gridTemplateColumns: '1.05fr 0.95fr',
        gap: 56,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
      className: "sa-eyebrow"
    }, "Enterprise Security \xB7 \u4F01\u696D\u7D1A\u9632\u8B77"), /*#__PURE__*/React.createElement("h1", {
      style: {
        fontSize: 'var(--fs-display)',
        fontWeight: 800,
        lineHeight: 1.08,
        margin: '16px 0 20px',
        color: 'var(--navy-900)'
      }
    }, "Intelligent Security,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--teal-700)'
      }
    }, "Micro Precision")), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 'var(--fs-lg)',
        color: 'var(--text-muted)',
        lineHeight: 1.6,
        maxWidth: 480,
        margin: '0 0 28px'
      }
    }, "SecuAgent detects, isolates, and resolves threats before they reach you \u2014 with precision measured in milliseconds, across every endpoint in your fleet."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        marginBottom: 28
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      size: "lg",
      onClick: onDemo
    }, "Get protected"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      onClick: onDemo
    }, "Book a demo")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 20,
        alignItems: 'center',
        color: 'var(--text-muted)',
        fontSize: 'var(--fs-sm)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": "shield-check",
      style: {
        width: 16,
        height: 16,
        color: 'var(--teal-700)'
      }
    }), " SOC 2 Type II"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": "lock",
      style: {
        width: 16,
        height: 16,
        color: 'var(--teal-700)'
      }
    }), " ISO 27001"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": "check-circle",
      style: {
        width: 16,
        height: 16,
        color: 'var(--teal-700)'
      }
    }), " GDPR ready"))), /*#__PURE__*/React.createElement(HeroVisual, null)));
  }
  function HeroVisual() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        borderRadius: 'var(--radius-xl)',
        overflow: 'hidden',
        background: 'linear-gradient(150deg, var(--navy-800), var(--navy-900))',
        boxShadow: 'var(--shadow-xl)',
        padding: 24,
        aspectRatio: '4/3'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        backgroundImage: "url('../../assets/pattern.png')",
        backgroundSize: '170px',
        opacity: 0.14,
        filter: 'brightness(1.7)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: '#fff',
        fontWeight: 700,
        fontSize: 15
      }
    }, "Threat Console"), /*#__PURE__*/React.createElement(Badge, {
      variant: "teal"
    }, "Live")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 12
      }
    }, [['Endpoints', '2,481', 'shield'], ['Threats blocked', '19,204', 'ban'], ['Median detection', '4.2ms', 'zap'], ['Fleet health', '99.99%', 'activity']].map(([l, v, ic]) => /*#__PURE__*/React.createElement("div", {
      key: l,
      style: {
        background: 'rgba(255,255,255,0.06)',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 10,
        padding: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        color: 'var(--teal-300)',
        fontSize: 11,
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.1em'
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": ic,
      style: {
        width: 14,
        height: 14
      }
    }), l), /*#__PURE__*/React.createElement("div", {
      style: {
        color: '#fff',
        fontSize: 24,
        fontWeight: 800,
        marginTop: 6,
        letterSpacing: '-0.02em'
      }
    }, v)))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        background: 'rgba(255,255,255,0.06)',
        border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 10,
        padding: 14,
        display: 'flex',
        flexDirection: 'column',
        gap: 9
      }
    }, [['192.168.4.12', 'Isolated', 'var(--teal-300)'], ['workstation-84', 'Resolved', '#8fd6a6'], ['api-gateway-2', 'Monitoring', 'var(--navy-200)']].map(([n, s, c]) => /*#__PURE__*/React.createElement("div", {
      key: n,
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        fontSize: 12,
        color: 'rgba(255,255,255,0.85)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)'
      }
    }, n), /*#__PURE__*/React.createElement("span", {
      style: {
        color: c,
        fontWeight: 600
      }
    }, s)))))));
  }
  window.Hero = Hero;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Pricing.jsx
try { (() => {
// SecuAgent website — Pricing
(function () {
  const {
    Button,
    Card,
    Badge
  } = window.SecuAgentDesignSystem_5f0b3a;
  function Pricing({
    onDemo
  }) {
    const [annual, setAnnual] = React.useState(true);
    const tiers = [{
      name: 'Starter',
      priceM: 8,
      blurb: 'For small teams securing their first endpoints.',
      feats: ['Up to 50 endpoints', 'Continuous detection', 'Email support', 'SOC 2 report'],
      cta: 'Start free trial',
      featured: false
    }, {
      name: 'Business',
      priceM: 14,
      blurb: 'For growing companies that need automation.',
      feats: ['Up to 1,000 endpoints', 'Auto-remediation', 'Zero-trust access', 'Priority support', 'ISO 27001 + GDPR'],
      cta: 'Book a demo',
      featured: true
    }, {
      name: 'Enterprise',
      priceM: null,
      blurb: 'For large fleets with custom requirements.',
      feats: ['Unlimited endpoints', 'Dedicated SOC analyst', 'Custom playbooks', 'SSO & SCIM', '99.99% uptime SLA'],
      cta: 'Contact sales',
      featured: false
    }];
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: 'var(--gray-50)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '88px 32px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'center',
        marginBottom: 40
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "sa-eyebrow"
    }, "Pricing"), /*#__PURE__*/React.createElement("h2", {
      style: {
        fontSize: 'var(--fs-h1)',
        fontWeight: 800,
        margin: '14px 0 20px',
        color: 'var(--navy-900)'
      }
    }, "Straightforward, per-endpoint pricing"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'inline-flex',
        background: '#fff',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-pill)',
        padding: 4
      }
    }, [['Monthly', false], ['Annual −20%', true]].map(([l, val]) => /*#__PURE__*/React.createElement("button", {
      key: l,
      onClick: () => setAnnual(val),
      style: {
        border: 'none',
        cursor: 'pointer',
        padding: '8px 18px',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--fs-sm)',
        fontWeight: 700,
        background: annual === val ? 'var(--navy-700)' : 'transparent',
        color: annual === val ? '#fff' : 'var(--navy-700)',
        transition: 'all var(--dur-fast)'
      }
    }, l)))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 24,
        alignItems: 'stretch'
      }
    }, tiers.map(t => {
      const price = t.priceM == null ? null : annual ? Math.round(t.priceM * 0.8) : t.priceM;
      return /*#__PURE__*/React.createElement(Card, {
        key: t.name,
        padding: "0",
        style: {
          border: t.featured ? '2px solid var(--teal-700)' : '1px solid var(--border-subtle)',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: t.featured ? 'var(--shadow-lg)' : 'var(--shadow-sm)'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          padding: 28,
          display: 'flex',
          flexDirection: 'column',
          gap: 6,
          borderBottom: '1px solid var(--border-subtle)'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 10
        }
      }, /*#__PURE__*/React.createElement("h3", {
        style: {
          fontSize: 'var(--fs-h3)',
          fontWeight: 700,
          color: 'var(--navy-900)'
        }
      }, t.name), t.featured && /*#__PURE__*/React.createElement(Badge, {
        variant: "teal"
      }, "Most popular")), /*#__PURE__*/React.createElement("p", {
        style: {
          fontSize: 'var(--fs-sm)',
          color: 'var(--text-muted)',
          margin: 0,
          minHeight: 40
        }
      }, t.blurb), /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, price == null ? /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 32,
          fontWeight: 800,
          color: 'var(--navy-900)'
        }
      }, "Custom") : /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: 40,
          fontWeight: 800,
          color: 'var(--navy-900)',
          letterSpacing: '-0.02em'
        }
      }, "$", price), /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-muted)',
          fontSize: 14
        }
      }, " /endpoint/mo")))), /*#__PURE__*/React.createElement("div", {
        style: {
          padding: 28,
          display: 'flex',
          flexDirection: 'column',
          gap: 12,
          flex: 1
        }
      }, t.feats.map(f => /*#__PURE__*/React.createElement("div", {
        key: f,
        style: {
          display: 'flex',
          gap: 10,
          alignItems: 'center',
          fontSize: 'var(--fs-sm)',
          color: 'var(--text-body)'
        }
      }, /*#__PURE__*/React.createElement("i", {
        "data-lucide": "check",
        style: {
          width: 16,
          height: 16,
          color: 'var(--teal-700)',
          flexShrink: 0
        }
      }), f)), /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 'auto',
          paddingTop: 12
        }
      }, /*#__PURE__*/React.createElement(Button, {
        variant: t.featured ? 'accent' : 'secondary',
        block: true,
        onClick: onDemo
      }, t.cta))));
    }))));
  }
  window.Pricing = Pricing;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Pricing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Product.jsx
try { (() => {
// SecuAgent website — Product split section + dark CTA band
(function () {
  const {
    Button
  } = window.SecuAgentDesignSystem_5f0b3a;
  function Product() {
    const points = [['Deploy in minutes', 'A single lightweight agent installs across Windows, macOS, and Linux — no reboot, no downtime.'], ['Precision over noise', 'Correlated signals mean fewer false positives, so your team acts on what actually matters.'], ['Scales with you', 'From 10 endpoints to 100,000 — the same console, the same millisecond response.']];
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: '#fff'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: 'var(--container-max)',
        margin: '0 auto',
        padding: '88px 32px',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 64,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
      className: "sa-eyebrow"
    }, "Why SecuAgent"), /*#__PURE__*/React.createElement("h2", {
      style: {
        fontSize: 'var(--fs-h1)',
        fontWeight: 800,
        margin: '14px 0 24px',
        color: 'var(--navy-900)',
        lineHeight: 1.15
      }
    }, "Security that stays out of your way"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 22
      }
    }, points.map(([t, d]) => /*#__PURE__*/React.createElement("div", {
      key: t,
      style: {
        display: 'flex',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flexShrink: 0,
        width: 30,
        height: 30,
        borderRadius: 'var(--radius-sm)',
        background: 'var(--teal-100)',
        color: 'var(--teal-700)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": "check",
      style: {
        width: 18,
        height: 18
      }
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
      style: {
        fontSize: 'var(--fs-h4)',
        fontWeight: 700,
        color: 'var(--navy-900)',
        margin: '2px 0 4px'
      }
    }, t), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 'var(--fs-body)',
        color: 'var(--text-muted)',
        lineHeight: 1.6,
        margin: 0
      }
    }, d)))))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderRadius: 'var(--radius-xl)',
        border: '1px solid var(--border-subtle)',
        boxShadow: 'var(--shadow-lg)',
        overflow: 'hidden',
        background: '#fff'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--navy-800)',
        padding: '12px 16px',
        display: 'flex',
        gap: 7
      }
    }, ['#ff5f57', '#febc2e', '#28c840'].map(c => /*#__PURE__*/React.createElement("span", {
      key: c,
      style: {
        width: 11,
        height: 11,
        borderRadius: 999,
        background: c
      }
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 22,
        display: 'flex',
        flexDirection: 'column',
        gap: 12
      }
    }, [['Endpoint compromised', 'workstation-84 · 12:04:07', 'danger'], ['Threat isolated automatically', 'playbook: quarantine-host', 'teal'], ['Root cause identified', 'phishing attachment · resolved', 'success']].map(([t, s, v], i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 12,
        alignItems: 'center',
        padding: 14,
        borderRadius: 'var(--radius-md)',
        background: 'var(--gray-50)',
        border: '1px solid var(--border-subtle)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: 999,
        background: v === 'danger' ? 'var(--danger)' : v === 'teal' ? 'var(--teal-700)' : 'var(--success)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 700,
        color: 'var(--navy-900)'
      }
    }, t), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-mono)'
      }
    }, s))))))));
  }
  function CTABand({
    onDemo
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        position: 'relative',
        background: 'linear-gradient(135deg, var(--navy-800), var(--navy-900))',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        backgroundImage: "url('../../assets/pattern.png')",
        backgroundSize: '180px',
        opacity: 0.12,
        filter: 'brightness(1.7)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        maxWidth: 'var(--container-narrow)',
        margin: '0 auto',
        padding: '80px 32px',
        textAlign: 'center'
      }
    }, /*#__PURE__*/React.createElement("h2", {
      style: {
        fontSize: 'var(--fs-h1)',
        fontWeight: 800,
        color: '#fff',
        margin: '0 0 16px'
      }
    }, "Stay a step ahead of every threat"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontSize: 'var(--fs-lg)',
        color: 'var(--navy-200)',
        lineHeight: 1.6,
        margin: '0 0 32px'
      }
    }, "See SecuAgent protect a live fleet in under 20 minutes. No credit card, no obligation."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 12,
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "accent",
      size: "lg",
      onClick: onDemo
    }, "Book a demo"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "lg",
      onClick: onDemo,
      style: {
        color: '#fff'
      }
    }, "Start free trial"))));
  }
  window.Product = Product;
  window.CTABand = CTABand;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Product.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.FeatureTile = __ds_scope.FeatureTile;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
